MyProject - Multipage Responsive Website

Project purpose
This repository contains a simple, responsive multipage website template intended for learning and demonstration.
It includes three HTML pages (Home, About, Services), a shared CSS file, and a single JavaScript file that
handles navigation toggles, form validation and small interactions.

Structure
/ (root)
  index.html        - Home page with hero, features and contact form
  about.html        - About page describing purpose and team
  services.html     - Services listing page
  /css/styles.css   - All styles (mobile-first, responsive)
  /js/main.js       - JS for navigation toggles and form validation
  /images           - Placeholder for images

How this meets the assignment
- Semantic HTML5 structure across pages.
- Responsive design using CSS grid/flex and media queries.
- JavaScript demonstrates functions with parameters and return values (validateField, mockSubmit).
- Interactivity: mobile nav toggle, form validation, and accessible states.

Deployment instructions
Option 1 - GitHub Pages
1. Create a new GitHub repository and push the project files.
2. In repository settings, under Pages, select the branch (usually main) and root folder.
3. Save and wait a minute. Your site will be available at https://<username>.github.io/<repo>.

Option 2 - Netlify
1. Sign in to Netlify and click 'Add new site' > 'Import from Git'.
2. Connect your Git provider, pick the repository and deploy.
3. Netlify will provide a live URL and continuous deployment on push.

Option 3 - Vercel
1. Sign in to Vercel, import the Git repository and deploy.
2. Vercel will auto-detect a static site and provide a live URL.

Notes
- Test links and scripts after deployment.
- Use meaningful commit messages and organize future features into folders.
