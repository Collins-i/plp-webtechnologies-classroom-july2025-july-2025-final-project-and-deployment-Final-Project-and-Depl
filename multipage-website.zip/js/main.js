/* Main JS for navigation, form validation and small interactions */

// Navigation toggle for mobile
function initNavToggle(toggleId, navId) {
  const toggle = document.getElementById(toggleId);
  const nav = document.getElementById(navId);
  if (!toggle || !nav) return;

  toggle.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(isOpen));
  });

  // Close nav when clicking outside on small screens
  document.addEventListener('click', (e) => {
    if (!nav.contains(e.target) && !toggle.contains(e.target) && nav.classList.contains('open')) {
      nav.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
    }
  });
}

// Initialize nav toggles for each page (IDs differ per page)
initNavToggle('navToggle', 'primaryNav');
initNavToggle('navToggleAbout', 'primaryNavAbout');
initNavToggle('navToggleServices', 'primaryNavServices');


// Simple form validation demonstrating parameters and return values
function validateField(value, rules) {
  // rules is an object: { required: true, minLength: 3, email: true }
  if (rules.required && !value.trim()) return { valid:false, message: 'This field is required.' };
  if (rules.minLength && value.trim().length < rules.minLength) return { valid:false, message: 'Too short.' };
  if (rules.email) {
    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    if (!pattern.test(value.trim())) return { valid:false, message: 'Enter a valid email.' };
  }
  return { valid:true };
}

function initContactForm(formId) {
  const form = document.getElementById(formId);
  if (!form) return;

  const name = form.querySelector('#name');
  const email = form.querySelector('#email');
  const message = form.querySelector('#message');
  const status = form.querySelector('#formStatus');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let valid = true;

    const nameCheck = validateField(name.value, { required:true, minLength:2 });
    document.getElementById('nameError').textContent = nameCheck.valid ? '' : nameCheck.message;
    if (!nameCheck.valid) valid = false;

    const emailCheck = validateField(email.value, { required:true, email:true });
    document.getElementById('emailError').textContent = emailCheck.valid ? '' : emailCheck.message;
    if (!emailCheck.valid) valid = false;

    const msgCheck = validateField(message.value, { required:true, minLength:5 });
    document.getElementById('messageError').textContent = msgCheck.valid ? '' : msgCheck.message;
    if (!msgCheck.valid) valid = false;

    if (!valid) {
      status.textContent = 'Please fix the errors above.';
      status.style.color = '#b00020';
      return;
    }

    // Simulate submission and show success using a function that returns a status object
    const submitResult = mockSubmit({ name: name.value.trim(), email: email.value.trim(), message: message.value.trim() });
    if (submitResult.success) {
      status.textContent = 'Message sent successfully.';
      status.style.color = 'green';
      form.reset();
    } else {
      status.textContent = 'Submission failed. Please try again later.';
      status.style.color = '#b00020';
    }
  });
}

// Example function representing an API submit (mock)
function mockSubmit(payload) {
  // payload parameter demonstrates passing data to a function.
  // Return value is an object, demonstrating return of structured data.
  console.log('Submitting payload', payload);
  return { success:true, timestamp: Date.now() };
}

// Initialize contact form
initContactForm('contactForm');

// Accessibility: reduce motion preference check (example of scope awareness)
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
if (reduceMotion) {
  document.documentElement.classList.add('reduced-motion');
}
